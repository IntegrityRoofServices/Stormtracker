document.addEventListener('DOMContentLoaded', function () {
    // Initialize the map
    var map = L.map('storm-map').setView([28.5383, -81.3792], 7); // Default to Central Florida

    // Add tile layer to the map
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map);

    // Data passed from PHP to JavaScript via localized script
    if (typeof stormData !== 'undefined' && stormData.length > 0) {
        stormData.forEach(function (cityData) {
            var lat = cityData.lat;
            var lon = cityData.lon;
            var city = cityData.city;
            var description = cityData.description;

            // Add marker for the city
            L.marker([lat, lon])
                .addTo(map)
                .bindPopup('<strong>' + city + '</strong><br>' + description);
        });
    } else {
        console.error('No storm data available.');
    }
});
