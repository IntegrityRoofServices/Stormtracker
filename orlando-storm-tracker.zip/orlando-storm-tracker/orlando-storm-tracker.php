<?php
/**
 * Plugin Name: Storm Tracker
 * Description: A plugin to track storms, display an interactive map, and allow users to manage cities for alerts and storm tracking. Includes integration with AccuLynx for customer data and secure dashboards.
 * Version: 3.0
 * Author: Your Name
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue plugin styles and scripts.
 */
function ost_enqueue_assets() {
    wp_enqueue_style('ost-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('ost-leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true);
    wp_enqueue_style('ost-leaflet-style', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
    wp_enqueue_script('ost-script', plugin_dir_url(__FILE__) . 'assets/script.js', ['jquery', 'ost-leaflet'], null, true);
}
add_action('wp_enqueue_scripts', 'ost_enqueue_assets');

/**
 * Create a shortcode to display storm data and an interactive map.
 *
 * @return string
 */
function ost_display_storm_data() {
    $api_key = get_option('ost_api_key'); // Get API key from settings
    $cities = get_option('ost_cities', []);

    if (empty($cities)) {
        return '<p>No cities configured. Please add cities in the settings.</p>';
    }

    $weather_data = [];

    foreach ($cities as $city) {
        // Split city into name and state (if provided)
        $city_parts = explode(',', $city);
        $city_name = trim($city_parts[0]);
        $state_code = isset($city_parts[1]) ? trim($city_parts[1]) : '';
        $country_code = 'US'; // Default to the United States

        // Construct API URL
        $api_url = "https://api.openweathermap.org/data/2.5/forecast?q={$city_name},{$state_code},{$country_code}&appid={$api_key}&units=imperial";

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            continue;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($data['cod']) && $data['cod'] === '200') {
            $weather_data[$city] = $data;
        }
    }

    if (empty($weather_data)) {
        return '<p>Unable to retrieve storm data at the moment. Please try again later.</p>';
    }

    ob_start();
    ?>
    <div class="ost-storm-tracker">
        <h3>Storm Tracker</h3>
        <div id="storm-map" style="width: 100%; height: 500px;"></div>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var map = L.map('storm-map').setView([28.5383, -81.3792], 7); // Central Florida default view

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19,
                }).addTo(map);

                <?php foreach ($weather_data as $city => $data): ?>
                    <?php 
                    $lat = $data['city']['coord']['lat']; 
                    $lon = $data['city']['coord']['lon']; 
                    $description = $data['list'][0]['weather'][0]['description']; 
                    $temp = $data['list'][0]['main']['temp']; 
                    $time = date('g:i A', strtotime($data['list'][0]['dt_txt']));
                    ?>

                    L.marker([<?php echo $lat; ?>, <?php echo $lon; ?>])
                        .addTo(map)
                        .bindPopup('<strong><?php echo esc_js($city); ?></strong><br><?php echo esc_js($description); ?><br>Temp: <?php echo esc_js($temp); ?>°F<br>Time: <?php echo esc_js($time); ?>');
                <?php endforeach; ?>
            });
        </script>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('storm_tracker', 'ost_display_storm_data');

/**
 * Create a settings page for the plugin.
 */
function ost_register_settings() {
    add_options_page(
        'Storm Tracker Settings',
        'Storm Tracker',
        'manage_options',
        'ost-settings',
        'ost_settings_page'
    );
}
add_action('admin_menu', 'ost_register_settings');

/**
 * Render the settings page.
 */
function ost_settings_page() {
    $cities = get_option('ost_cities', []);
    ?>
    <div class="wrap">
        <h1>Storm Tracker Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ost_options_group');
            do_settings_sections('ost-settings');
            submit_button();
            ?>
        </form>

        <h2>Manage Cities</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">City</th>
                    <td><input type="text" name="ost_new_city" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('Add City', 'primary', 'add_city'); ?>
        </form>

        <h3>Current Cities</h3>
        <ul>
            <?php foreach ($cities as $city): ?>
                <li>
                    <?php echo esc_html($city); ?>
                    <a href="?page=ost-settings&remove_city=<?php echo urlencode($city); ?>">Remove</a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php

    if (isset($_POST['add_city']) && !empty($_POST['ost_new_city'])) {
        $new_city = sanitize_text_field($_POST['ost_new_city']);

        if (!in_array($new_city, $cities)) {
            $cities[] = $new_city;
            update_option('ost_cities', $cities);
        }
    }

    if (isset($_GET['remove_city'])) {
        $city_to_remove = urldecode($_GET['remove_city']);
        $cities = array_filter($cities, function ($city) use ($city_to_remove) {
            return $city !== $city_to_remove;
        });
        update_option('ost_cities', $cities);
    }
}

/**
 * Register plugin settings.
 */
function ost_register_plugin_settings() {
    register_setting('ost_options_group', 'ost_api_key');
    register_setting('ost_options_group', 'acculynx_api_key');
    register_setting('ost_options_group', 'acculynx_api_secret');
    add_settings_section(
        'ost_settings_section',
        'API Settings',
        null,
        'ost-settings'
    );

    add_settings_field(
        'ost_api_key',
        'OpenWeatherMap API Key',
        'ost_api_key_field_callback',
        'ost-settings',
        'ost_settings_section'
    );

    add_settings_field(
        'acculynx_api_key',
        'AccuLynx API Key',
        'acculynx_api_key_field_callback',
        'ost-settings',
        'ost_settings_section'
    );

    add_settings_field(
        'acculynx_api_secret',
        'AccuLynx API Secret',
        'acculynx_api_secret_field_callback',
        'ost-settings',
        'ost_settings_section'
    );
}
add_action('admin_init', 'ost_register_plugin_settings');

/**
 * Render the API key input fields.
 */
function ost_api_key_field_callback() {
    $api_key = get_option('ost_api_key');
    ?>
    <input type="text" name="ost_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
    <p class="description">Enter your OpenWeatherMap API key here.</p>
    <?php
}

function acculynx_api_key_field_callback() {
    $api_key = get_option('acculynx_api_key');
    ?>
    <input type="text" name="acculynx_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
    <p class="description">Enter your AccuLynx API key here.</p>
    <?php
}

function acculynx_api_secret_field_callback() {
    $api_secret = get_option('acculynx_api_secret');
    ?>
    <input type="text" name="acculynx_api_secret" value="<?php echo esc_attr($api_secret); ?>" class="regular-text">
    <p class="description">Enter your AccuLynx API secret here.</p>
    <?php
}
?>
